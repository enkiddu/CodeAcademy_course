# -*- coding: utf-8 -*-
"""
Created on Wed Feb 28 16:06:32 2018

@author: maitzc
"""

from matplotlib import pyplot as plt
import pandas as pd


species = pd.read_csv('species_info.csv')
#print species.count
#print species.category.unique()
#print species.conservation_status.unique()

species.fillna('No Intervention', inplace=True)
grouped = species.groupby('conservation_status').count()
#print grouped

protection_counts = species.groupby('conservation_status')\
    .scientific_name.count().reset_index()\
    #.sort_values(by='scientific_name')
#print protection_counts
    
plt.bar(protection_counts['conservation_status'], protection_counts['scientific_name'])
ax = plt.subplot()
ax.set_xticks(range(len(protection_counts['conservation_status'])))
ax.set_xticklabels(protection_counts['conservation_status'], rotation=30)
plt.ylabel('Number of Species')
plt.title('Conservation Status by Species')
plt.show()

is_protected = lambda row : 'True' if row['conservation_status'] != 'No Intervention' else 'False'
species['is_protected'] = species.apply(is_protected, axis=1)

category_counts = species.groupby(['category', 'is_protected']).scientific_name.count().reset_index()
#print category_counts.head(10)
category_pivot = category_counts.pivot(index = 'category', 
                                       columns = 'is_protected', 
                                       values = 'scientific_name').reset_index()
category_pivot.columns = ['category', 'not_protected', 'protected']
category_pivot['percent_protected'] = (100 * category_pivot['protected']) / (category_pivot['protected'] + category_pivot['not_protected'])
#print category_pivot.head(10)

from scipy.stats import chi2_contingency
contingency = [[922539, 26913],
               [614682, 18609]]
chi2, pval, dof, expected = chi2_contingency(contingency)


observations = pd.read_csv('observations.csv')
is_sheep = lambda row: 'True' if 'Sheep' in row['common_names'] else 'False'
species['is_sheep'] = species.apply(is_sheep, axis=1)
sheep_species = species[(species.is_sheep == 'True') &
                        (species.category == 'Mammal')]
sheep_observations = sheep_species.merge(observations, on='scientific_name')
obs_by_park = sheep_observations.groupby(['scientific_name', 'common_names', 'park_name']).observations.sum().reset_index()
total_obs_by_park = sheep_observations.groupby('park_name').observations.sum().reset_index()

plt.bar(total_obs_by_park['park_name'], total_obs_by_park['observations'])
ax = plt.subplot()
ax.set_xticks(range(len(total_obs_by_park['park_name'])))
ax.set_xticklabels(total_obs_by_park['park_name'], rotation=30)
plt.ylabel('Number of Observations')
plt.title('Observations of Sheep per Week')
plt.show()


categories = species.groupby('category').scientific_name.count().reset_index()
plt.pie(categories['scientific_name'], 
        labels=categories['category'])
plt.axis('equal')

merger = species.merge(observations, on='scientific_name')
protected = merger[merger.is_protected == 'True']
end_park = merger.groupby(['park_name', 'is_protected']).observations.sum().reset_index()
end_status = end_park.pivot(index = 'park_name',
                             columns = 'is_protected',
                             values = 'observations').reset_index()
end_status.columns = ['Park Name', 'Not Protected Observations', 'Protected Observations']
end_status['percent_observations_protected'] = (100 * end_status['Protected Observations']) / (end_status['Protected Observations'] + end_status['Not Protected Observations'])



